// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAGMBsh0xbZTBIZXZyAjK_uK3bGAHLW5cA",
  authDomain: "swiggy-a58e7.firebaseapp.com",
  projectId: "swiggy-a58e7",
  storageBucket: "swiggy-a58e7.firebasestorage.app",
  messagingSenderId: "1067008216255",
  appId: "1:1067008216255:web:7e30ff5694a6f08a470a0a"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);