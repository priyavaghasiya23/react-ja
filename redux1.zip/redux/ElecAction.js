// actions.js
// export const setElectronics = (payload) => ({
//     type: "SET_ELECTRONICS",
//     payload,
// });

export const fetchElectronicProducts = () => {
    return async (dispatch) => { 
        try {
            const response = await fetch('https://fakestoreapi.com/products/category/jewelery'); 
            const data = await response.json();
            dispatch({
                type: "SET_ELECTRONICS",
                payload: data,
            });
        } catch (error) {
            console.error("Error fetching electronic products:", error);
        }
    };
};
