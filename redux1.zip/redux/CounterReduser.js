const initialState = {
    value: 0,
    isRunning: false,
  };
  
  export function counterReducer(state = initialState, action) {
    switch (action.type) {
      case 'INCREMENT':
        return { ...state, value: state.value + 1 };
      case 'START':
        return { ...state, isRunning: true };
      case 'STOP':
        return { ...state, isRunning: false };
      case 'RESET':
        return { value: 0, isRunning: false };
      default:
        return state;
    }
  }
  