import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchElectronicProducts } from './ElecAction';
import { Link } from 'react-router-dom';

const Electronic = () => {
    const dispatch = useDispatch();
    const data = useSelector((state) => state.Elec);

    useEffect(() => {
        dispatch(fetchElectronicProducts());
    }, [dispatch]);

    if (!data || data.length === 0) {
        return <p>No products available.</p>;
    }

    return (
        <div>
            <h1>Electronic Products</h1>
            <ul>
                {data.map((item) => (
                    <li key={item.id}>
                        <Link to={`/product/${item.id}`}>{item.title}</Link>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Electronic;