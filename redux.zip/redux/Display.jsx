import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { deleteAction, updateAction } from './Action';

const Display = () => {
    const data = useSelector((store) => store.todo); 
    const dispatch = useDispatch();

    const [isEditing, setIsEditing] = useState(null);
    const [editValue, setEditValue] = useState(''); 

    const deletetodo = (index) => {
        dispatch(deleteAction(index)); 
    };

    const startEdit = (index, value) => {
        setIsEditing(index); 
        setEditValue(value); 
    };

    const saveEdit = (index) => {
        if (editValue.trim()) {
            dispatch(updateAction(index, editValue)); 
            setIsEditing(null); 
            setEditValue(''); 
        }
    };

    return (
        <div>
            <ul>
                {data.map((el, i) => (
                    <li key={i}>
                        {isEditing === i ? ( 
                            <>
                                <input
                                    type="text"
                                    value={editValue}
                                    onChange={(e) => setEditValue(e.target.value)}
                                />
                                <button onClick={() => saveEdit(i)}>Update</button> 
                                <button onClick={() => setIsEditing(null)}>Cancel</button> 
                            </>
                        ) : (
                            <>
                                {el}
                                <button onClick={() => startEdit(i, el)}>Edit</button>
                                <button onClick={() => deletetodo(i)}>Delete</button>
                            </>
                        )}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Display;
