import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';

const Cart = () => {
    const location = useLocation();
    const product = location.state?.product; // Retrieve product passed via navigation
    const [quantity, setQuantity] = useState(1);

    if (!product) {
        return <h2>No product in the cart. Add a product to see details.</h2>;
    }

    const handleIncrease = () => setQuantity(quantity + 1);
    const handleDecrease = () => {
        if (quantity > 1) setQuantity(quantity - 1);
    };

    return (
        <div>
            <h1>Cart</h1>
            <div style={{ border: '1px solid #ccc', padding: '20px', maxWidth: '400px', margin: 'auto' }}>
                <img
                    src={product.image}
                    alt={product.title}
                    style={{ width: '100px', height: '100px', marginBottom: '10px' }}
                />
                <h2>{product.title}</h2>
                <p>{product.description}</p>
                <p>Price: ${product.price}</p>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <button onClick={handleDecrease}>-</button>
                    <span>{quantity}</span>
                    <button onClick={handleIncrease}>+</button>
                </div>
                <p>Total: ${(product.price * quantity).toFixed(2)}</p>
            </div>
        </div>
    );
};

export default Cart;