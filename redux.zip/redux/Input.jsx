import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addAction } from './Action';

const Input = () => {
    const [state, setState] = useState('');
    const dispatch = useDispatch();

    function addtext(e) {
        setState(e.target.value);
    }

    function add() {
        if (state.trim()) {
            dispatch(addAction(state));
            setState('');
        }
    }

    return (
        <div>
            <input type="text" value={state} onChange={addtext} />
            <button onClick={add}>Add</button>
        </div>
    );
};

export default Input;
